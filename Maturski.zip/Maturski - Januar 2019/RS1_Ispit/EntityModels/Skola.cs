﻿namespace RS1_Ispit_asp.net_core.EntityModels
{
    public class Skola
    {
        public int Id { get; set; }
        public string Naziv{ get; set; }
    }
}
